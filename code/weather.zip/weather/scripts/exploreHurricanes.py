import csv
from scipy.stats import poisson
import numpy as np

NUM_DAYS = 365
MIN_YEAR = 1851 #1851
MAX_YEAR = 1966 #1966, 2015

def run():
	# 1. load the data. yearCountMap[2005] = 31
	yearCountMap = loadData()

	# 2. calculate simple statistics
	numYears = MAX_YEAR - MIN_YEAR
	numHurricanes = 0.0
	counts = []
	for year in range(MIN_YEAR, MAX_YEAR):
		numHurricanes += yearCountMap[year]
		counts.append(yearCountMap[year])

	# 3. calculate poisson stats
	rate = numHurricanes / numYears
	p = rate / NUM_DAYS
	print 'Poisson parameter estimation'
	print 'rate = ' + str(rate)
	print 'years = ' + str(numYears)
	print 'n = ' + str(NUM_DAYS)		
	print 'p = ' + str(p)	
	print ''

	# 4. calculate poisson PMF predictions
	X = poisson(rate)
	print 'Poisson predictions'
	for x in range(0,50):
		prediction = X.pmf(x) * numYears
		print str(x) + "\t" + str(prediction)
	print ''

	# 5. show histogram
	hist = np.histogram(counts, bins=range(40))
	print 'Actual histogram'
	for v in hist[0]:
		print v

def loadData():
	fileName = "hurdat2-1851-2015-021716.txt"
	filePath = "../hurdat/" + fileName 
	reader = csv.reader(open(filePath), skipinitialspace=True)
	yearCount = {}
	for row in reader:
		if(len(row) == 4):
			year = int(row[0][4:])
			if not year in yearCount:
				yearCount[year] = 0
			yearCount[year] += 1
	return yearCount

if __name__ == '__main__':
	run()