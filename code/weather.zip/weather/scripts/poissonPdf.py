import csv
from scipy.stats import poisson
import numpy as np

def run():
	rate = 8.6
	X = poisson(rate)
	print X.cdf(15)
	print 1- X.cdf(15)

if __name__ == '__main__':
	run()